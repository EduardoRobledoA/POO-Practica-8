
package herencia;

/**
 * Esta clase representa un polígono en general que solo contiene método para el área y el perímetro.
 * @author Daniel Rojas
 */
public class Poligono {

    /**
     * Este es el constructor vacío de la clase polígono.
     */
    public Poligono() {
    }
    /**
     * Este es el método que permite al usuario obtener el área. No devuelve nada.
     * @return Devuelve un cero. No está desarrollado.
     */
    public float area(){
        return 0;
    }
    /**
     * Este es el método que permite al usuario obtener el perímetro. No devuelve nada.
     * @return Devuelve un cero. No está desarrollado.
     */
    public float perimetro(){
        return 0;
    }
    /**
     * Este es el método que permite al usuario observar los atributos de la clase. No devuelve nada.
     * @return Devuelve una cadena "Poligono". No está desarrollado.
     */
    @Override
    public String toString() {
        return "Poligono{" + '}';
    }
    
}
