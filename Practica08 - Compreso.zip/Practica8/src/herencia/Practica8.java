
package herencia;

/**
 * Esta clase es la clase principal del proyecto que se ejecutará de manera prioritaria.
 * @author Daniel Rojas
 */
public class Practica8 {

    /**
     * Esta es el método principal que se va a ejecutar.
     * @param args No recibe parámetros de forma manual.
     */
    public static void main(String[] args) {
        
        System.out.println("ACT1*******************");
        
        Poligono poligono = new Poligono();
        System.out.println("Poligono "+poligono);
        
        Object objeto = new Object();
        System.out.println("Object "+objeto);
        
        objeto = poligono;
        System.out.println("Object como poligono "+objeto);
        
        System.out.println("ACT2*******************");
        
        poligono = new Triangulo();
        System.out.println(poligono);
        selector(poligono);
        
        poligono = new Cuadrilatero();
        System.out.println(poligono);
        selector(poligono);
        
        poligono = new Poligono();
        System.out.println(poligono);
        selector(poligono);
        
    }
    /**
     * Este método permite al usuario identificar a qué clase de poligono pertenece un objeto dado.
     * @param poligono Recibe un objeto de la clase polígono o una subclase de esta.
     */
    public static void selector(Poligono poligono){
        if(poligono instanceof Triangulo){
            System.out.println("El objeto es un triangulo");
        }else if(poligono instanceof Cuadrilatero){
            System.out.println("Es un cuadrilatero");
        }else{
            System.out.println("El objeto es otra figura");
        }
    }
    
    
}
