
package herencia;

/**
 * Esta clase representa un polígono de la clase Cuadrilátero.
 * @author Daniel Rojas
 */
public class Cuadrilatero extends Poligono{
    
    public float a,b,base,altura;
    public int alpha,beta,gamma;

    /**
     * Este es el constructor vacío de la clase Cuadrilátero.
     */
    public Cuadrilatero() {
    }

    /**
     * Este es el constructor que recibe todos los parámetros correspondientes a todos los atributos.
     * @param a Representa un lado "a" del cuadrilátero.
     * @param b Representa un lado "b" del cuadrilátero.
     * @param base Representa el valor de la base.
     * @param altura Representa el valor de la altura.
     * @param alpha Representa un ángulo "alpha" del cuadrilátero.
     * @param beta Representa un ángulo "beta" del cuadrilátero.
     * @param gamma  Representa un ángulo "gamma" del cuadrilátero.
     */
    public Cuadrilatero(float a, float b, float base, float altura, 
            int alpha, int beta, int gamma) {
        this.a = a;
        this.b = b;
        this.base = base;
        this.altura = altura;
        this.alpha = alpha;
        this.beta = beta;
        this.gamma = gamma;
    }

    /**
     * Este método permite obtener el valor almacenado en la variable "a".
     * @return Devuélve el valor almacenado en a.
     */
    public float getA() {
        return a;
    }
    /**
     * Este método permite al usuario establecer el valor de la variable "a".
     * @param a Recibe un valor flotante que se va a almacenar en "a".
     */
    public void setA(float a) {
        this.a = a;
    }
    /**
     * Este método permite obtener el valor almacenado en la variable "b".
     * @return Devuélve el valor almacenado en b.
     */
    public float getB() {
        return b;
    }
    /**
     * Este método permite al usuario establecer el valor de la variable "b".
     * @param b Recibe un valor flotante que se va a almacenar en "b".
     */
    public void setB(float b) {
        this.b = b;
    }
    /**
     * Este método permite obtener el valor almacenado en la variable "base".
     * @return Devuélve el valor almacenado en base.
     */
    public float getBase() {
        return base;
    }
    /**
     * Este método permite al usuario establecer el valor de la variable "base".
     * @param base Recibe un valor flotante que se va a almacenar en "base".
     */
    public void setBase(float base) {
        this.base = base;
    }
    /**
     * Este método permite obtener el valor almacenado en la variable "altura".
     * @return Devuélve el valor almacenado en altura.
     */
    public float getAltura() {
        return altura;
    }
    /**
     * Este método permite al usuario establecer el valor de la variable "altura".
     * @param altura Recibe un valor flotante que se va a almacenar en "altura".
     */
    public void setAltura(float altura) {
        this.altura = altura;
    }
    /**
     * Este método permite obtener el valor almacenado en la variable "alpha".
     * @return Devuélve el valor almacenado en alpha.
     */
    public int getAlpha() {
        return alpha;
    }
    /**
     * Este método permite al usuario establecer el valor de la variable "alpha".
     * @param alpha Recibe un valor entero que se va a almacenar en "a".
     */
    public void setAlpha(int alpha) {
        this.alpha = alpha;
    }
    /**
     * Este método permite obtener el valor almacenado en la variable "beta".
     * @return Devuélve el valor almacenado en beta.
     */
    public int getBeta() {
        return beta;
    }
    /**
     * Este método permite al usuario establecer el valor de la variable "beta".
     * @param beta Recibe un valor flotante que se va a almacenar en "beta".
     */
    public void setBeta(int beta) {
        this.beta = beta;
    }
    /**
     * Este método permite obtener el valor almacenado en la variable "gamma".
     * @return Devuélve el valor almacenado en gamma
     */
    public int getGamma() {
        return gamma;
    }
    /**
     * Este método permite al usuario establecer el valor de la variable "gamma".
     * @param gamma Recibe un valor entero que se va a almacenar en "gamma".
     */
    public void setGamma(int gamma) {
        this.gamma = gamma;
    }
    /**
     * Este método permite visualizar en texto los valores de los atributos de la clase.
     * @return Devuelve una cadena que contiene en texto los valores de los atributos de la clase.
     */
    @Override
    public String toString() {
        return "Cuadrilatero{" + "a=" + a + ", b=" + b + ", base=" + base + 
                ", altura=" + altura + ", alpha=" + alpha + ", beta=" + beta + 
                ", gamma=" + gamma + '}';
    }
    
    
    
}
