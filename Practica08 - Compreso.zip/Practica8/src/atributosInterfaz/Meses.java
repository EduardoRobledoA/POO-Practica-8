/**
 * Este paquete contiene el ejercicio de la Actividad 5.
 */
package atributosInterfaz;

/**
 * Esta interfaz funciona como un diccionario que relaciona números con meses del año.
 * @author Daniel Rojas
 */
public interface Meses {
    int UNO=1,DOS=2,TRES=3,CUATRO=4,CINCO=5,SEIS=6,SIETE=7,OCHO=8;
    int NUEVE=9,DIEZ=10,ONCE=11,DOCE=12;
    
    String[] NOMBRE_MESES = {"","enero","febrero","marzo",
        "abril","mayo","junio","julio","agosto","septiembre",
        "octubre","noviembre","diciembre"};
    
}
