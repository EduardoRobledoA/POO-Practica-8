/**
 * Este paquete contiene el ejercicio de la Actividad 5.
 */
package atributosInterfaz;

/**
 * Esta es la clase principal del paquete atributosInterfaz.
 * @author Daniel Rojas
 */
public class Practica084 {
    /**
     * Este es el método main de la clase.
     * @param args No recibe argumentos de forma manual.
     */
    public static void main(String[] args) {
        System.out.println("ACT5************************");
        System.out.println("El mes "+Meses.CUATRO+" corresponde a: ");
        System.out.println(Meses.NOMBRE_MESES[Meses.CUATRO]);
    }
}
