
package interfaz;
/**
 * Esta es la interfaz de un instrumento musical.
 * @author Daniel
 */
public interface InstrumentoMusical {
    //Por defecto todos los metodos son publicos
    /**
     * Este es el método "plantilla" para simular una demostración musical.
     */
    void tocar();
    /**
     * Este es el método "plantilla" para simular una afinación del instrumento.
     */
    void afinar();
    /**
     * Este es el método "plantilla" para indicar el tipo de instrumento.
     * @return No devuelve nada.
     */
    String tipoInstrumento();
}
