
package interfaz;

/**
 * Esta es la clase principal del paquete interfaz.
 * @author Daniel Rojas
 */
public class Practica083 {
    /**
     * Este es el método main de la clase.
     * @param args No recibe argumentos manualmente.
     */
    public static void main(String[] args) {
        System.out.println("ACT4*******************");
        
        InstrumentoMusical instrumento;
        
        instrumento = new Flauta();
        instrumento.tocar();
        instrumento.afinar();
        System.out.println(instrumento.tipoInstrumento());
        System.out.println(instrumento);
    }
}
