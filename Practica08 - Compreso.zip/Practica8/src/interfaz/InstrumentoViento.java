
package interfaz;
/**
 * Esta clase representa un instrumento musical de viento.
 * @author Daniel Rojas
 */
public class InstrumentoViento implements InstrumentoMusical{

    /**
     * Este es el constructor vacío de la clase.
     */
    public InstrumentoViento() {
    }
    /**
     * Este es el método sobrescrito para simular una demostración musical.
     */
    @Override
    public void tocar(){
        System.out.println("Estoy tocando un instrumento de viento");
    }
    /**
     * Este es el método sobrescrito para simular una afinación del instrumento.
     */
    @Override
    public void afinar(){
        System.out.println("Estoy afinando un instrumento de viento");
    }
    /**
     * Este es el método sobrescrito para indicar el tipo de instrumento.
     * @return Devuelve una cadena "Instrumento de viento".
     */
    @Override
    public String tipoInstrumento(){
        return "Instrumento de viento";
    }
    /**
     * Este método permite al usuario observar una cadena "InstrumentoViento{".
     * @return Un mensaje de texto.
     */
    @Override
    public String toString() {
        return "InstrumentoViento{" + '}';
    }
    
    
}
