
package interfaz;

/**
 * Esta clase representa un objeto flauta.
 * @author Daniel Rojas
 */
public class Flauta extends InstrumentoViento{

    /**
     * Este es el constructor vacío de la clase.
     */
    public Flauta() {
    }
    /**
     * Este es el método sobrescrito para indicar el tipo de instrumento.
     * @return Devuelve una cadena "Flauta".
     */
    @Override
    public String tipoInstrumento(){
        return "Flauta";
    }
    /**
     * Este método permite al usuario observar una cadena "Flauta{".
     * @return Un mensaje de texto.
     */
    @Override
    public String toString() {
        return "Flauta{" + '}';
    }
    
}
