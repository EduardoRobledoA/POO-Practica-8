
package claseAbstracta;

/**
 * Esta clase abstracta funciona como plantilla para la creación de polígonos.
 * @author Daniel Rojas
 */
public abstract class Poligono {
    public abstract float area();
    public abstract float perimetro();
    /**
     * Este método permite visualizar un mensaje "Poligono".
     * @return Devuelve un texto "Poligono".
     */
    @Override
    public String toString() {
        return "Poligono{" + '}';
    }


}
