
package claseAbstracta;

/**
 * Esta clase es la clase principal del paquete claseAbstracta.
 * @author Daniel Rojas
 */
public class Practica082 {
    /**
     * Es el método main de la clase principal.
     * @param args No se recibe ningún argumento manualmente.
     */
    public static void main(String[] args){
        System.out.println("ACT3**************************");
        
        Poligono poligono;
        
        poligono = new Triangulo();
        System.out.println(poligono);
        
        poligono = new Cuadrilatero();
        System.out.println(poligono);
        
    }
    
}
